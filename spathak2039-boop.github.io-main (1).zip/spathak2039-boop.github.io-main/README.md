# Santosh Pathak — personal website

This folder contains the complete static website. It can be opened locally or
hosted on GitHub Pages. No build command or package installation is needed.

## Preview before updating

Extract the ZIP, open this folder, and double-click `index.html`.
Check the homepage, CV, People page, publication filters, and poem links.
Resize the browser to see the mobile navigation.

The CV page has a **Print / Save as PDF** button. Use your browser's **Save as
PDF** option to create a PDF. There is no separate downloadable PDF CV included.

## Update the existing GitHub website

1. Open https://github.com/spathak2039-boop/spathak2039-boop.github.io.
2. On the branch used for the website, choose **Add file → Upload files**.
3. Upload the contents of this folder, including `index.html`, `cv.html`,
   `assets`, `literature`, `people`, `robots.txt`, `sitemap.xml`, `sitemap.txt`,
   and this README. Keep the folders and filenames as they are.
4. Commit the changes. If GitHub offers a pull request instead of a direct
   commit, merge it into the branch used by GitHub Pages.
5. Check the deployment under **Actions**, then open
   https://spathak2039-boop.github.io/ and refresh the page.

Upload the files inside the extracted folder. Uploading only the ZIP or the
outer `spathak2039-boop.github.io-main` folder will not update the homepage.
`index.html` must remain at the repository root for the existing setup.

## Changes in this revision

- Corrected 12 poem return links and the CV return link.
- Added working mobile navigation to the People page.
- Added Escape dismissal, outside-click dismissal, and focus handling to the
  navigation menu, with a fallback when JavaScript is unavailable.
- Corrected the misleading PDF download action; it now opens the CV's print
  control.
- Gave the Articles & Opinions tile its own destination at the existing essay.
- Adjusted the menu position, publication-link alignment, portrait sizing,
  narrow-card wrapping, and anchor scrolling.
- Added reduced-motion support and canonical URLs where missing.
- Made the XML sitemap valid without requiring a Jekyll build.

The existing design, academic information, portraits, publication links, and
all poem text are preserved. The People section remains an outline awaiting
your profiles; no biographies have been invented.

## Validation and remaining review

- Checked all 10 HTML pages and 57 local links and asset references.
- Confirmed all seven poems and three binary assets match the uploaded copy.
- Parsed the XML sitemap and checked JavaScript syntax.
- Checked navigation and publication-filter behavior with a JavaScript harness.

Visual browser verification was unavailable in the editing environment.
External publication and profile links were preserved but could not be checked
online. This package has not been published to the live website.

## Future content

The Research tile mentions teaching, but there is not yet a teaching-materials
section. You can add course descriptions or public lecture notes when ready.
The People page is also ready for your first biography or profile.

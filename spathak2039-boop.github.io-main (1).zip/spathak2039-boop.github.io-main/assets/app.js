(function () {
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.navlinks');

  if (menu && nav) {
    const mobileViewport = window.matchMedia('(max-width: 900px)');
    const setMenuOpen = (isOpen) => {
      nav.classList.toggle('open', isOpen);
      menu.setAttribute('aria-expanded', String(isOpen));
      menu.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
      menu.textContent = isOpen ? '×' : '☰';
    };

    menu.addEventListener('click', () => {
      setMenuOpen(!nav.classList.contains('open'));
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => setMenuOpen(false));
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && nav.classList.contains('open')) {
        setMenuOpen(false);
        menu.focus();
      }
    });

    document.addEventListener('click', (event) => {
      if (!menu.contains(event.target) && !nav.contains(event.target)) {
        const focusInNav = nav.contains(document.activeElement);
        const wasOpen = nav.classList.contains('open');
        setMenuOpen(false);
        if (wasOpen && focusInNav) menu.focus();
      }
    });

    mobileViewport.addEventListener('change', () => {
      const focusOnMenu = document.activeElement === menu;
      const focusInNav = nav.contains(document.activeElement);
      setMenuOpen(false);
      if (mobileViewport.matches && focusInNav) menu.focus();
      if (!mobileViewport.matches && focusOnMenu) nav.querySelector('a')?.focus();
    });

    // Only collapse navigation after its button has been initialized.
    document.documentElement.classList.add('js');
  }

  const filters = document.querySelectorAll('[data-publication-filter]');
  const publications = document.querySelectorAll('[data-pub-category]');
  filters.forEach((button) => {
    button.addEventListener('click', () => {
      filters.forEach((filter) => {
        filter.classList.toggle('active', filter === button);
        filter.setAttribute('aria-pressed', String(filter === button));
      });
      const category = button.dataset.publicationFilter;
      publications.forEach((publication) => {
        publication.hidden = category !== 'all' && publication.dataset.pubCategory !== category;
      });
    });
  });

  const input = document.querySelector('[data-resource-search]');
  if (input) {
    const items = document.querySelectorAll('[data-resource-item]');
    input.addEventListener('input', () => {
      const query = input.value.trim().toLocaleLowerCase();
      items.forEach((item) => {
        item.hidden = !item.textContent.toLocaleLowerCase().includes(query);
      });
    });
  }
})();

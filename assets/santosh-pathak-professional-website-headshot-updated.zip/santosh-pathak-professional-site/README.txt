Santosh Pathak Academic Website

FREE PUBLISHING WITH GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a public repository named: <your-github-username>.github.io
3. Upload index.html and the assets folder from this package.
4. Open Settings > Pages and publish from the main branch if needed.
5. Your site will be available at https://<your-github-username>.github.io

No paid domain is required. You can add a custom domain later if desired.

Important: Keep the assets folder next to index.html so the portrait displays correctly.
